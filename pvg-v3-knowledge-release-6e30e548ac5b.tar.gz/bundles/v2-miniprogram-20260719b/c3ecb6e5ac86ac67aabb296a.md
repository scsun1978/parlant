---
asset_id: pvg.v2.c3ecb6e5ac86ac67aabb296a
version: v2-83c40bb512bf
tenant_id: pvg
title: 的服务时间、乘车地点和收费标准是什么？
section: excel_knowledge
reviewer: v2-legacy-human-review
publisher: v3-staging-migration
published_at: '2026-07-18T20:00:00+08:00'
source_uri: viking://resources/pvg/excel/risk_control/机场交通/机场交通/risk_control-0467-的服务时间-乘车地点和收费标准是什么.md
status: published
knowledge_type: service_information
valid_from: '2026-07-19T00:00:00+08:00'
valid_until: '2026-10-17T00:00:00+08:00'
channel_scope:
- miniprogram
terminal_scope:
- ALL
revoked_at: ''
---
---
title: 的服务时间、乘车地点和收费标准是什么？
source_owner: PVG passenger service
source_type: excel_knowledge
source_id: risk_control-0467
version: 1.0
updated_at: 2026-04-30
effective_from: 2026-04-30
scope: demo_only
confidentiality: internal
review_status: approved_for_demo
---

# 的服务时间、乘车地点和收费标准是什么？

## 分类

- 一级分类：机场交通
- 二级分类：机场交通

## 标准答案

服务时间：1号航站楼：08:00-19:15
2号航站楼：08:03-19:18
收费标准：2元

## 意图标签

- 主意图：general_consultation
- 次意图：未标注

## 风险与来源

- 风险等级：Low
- 来源：Excel 原始资料
- 联系电话：已在 Demo 知识库中隐藏，需接入官方系统后按权限展示。
- 备注：以机场官方最新通知或现场指引为准。
