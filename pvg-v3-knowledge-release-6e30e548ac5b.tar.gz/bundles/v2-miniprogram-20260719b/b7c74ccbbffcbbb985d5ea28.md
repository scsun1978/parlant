---
asset_id: pvg.v2.b7c74ccbbffcbbb985d5ea28
version: v2-e1b75557a330
tenant_id: pvg
title: T2航站楼禁区内国际到达8.4米层80廊桥附近附近卫生间和配套设施情况如何？
section: excel_knowledge
reviewer: v2-legacy-human-review
publisher: v3-staging-migration
published_at: '2026-07-18T20:00:00+08:00'
source_uri: viking://resources/pvg/excel/risk_control/公共设施/卫生间/risk_control-0316-T2航站楼禁区内国际到达8-4米层80廊桥附近附近卫生间和配套设施情况如何.md
status: published
knowledge_type: service_information
valid_from: '2026-07-19T00:00:00+08:00'
valid_until: '2026-10-17T00:00:00+08:00'
channel_scope:
- miniprogram
terminal_scope:
- T2
revoked_at: ''
---
---
title: T2航站楼禁区内国际到达8.4米层80廊桥附近附近卫生间和配套设施情况如何？
source_owner: PVG passenger service
source_type: excel_knowledge
source_id: risk_control-0316
version: 1.0
updated_at: 2026-04-30
effective_from: 2026-04-30
scope: demo_only
confidentiality: internal
review_status: approved_for_demo
---

# T2航站楼禁区内国际到达8.4米层80廊桥附近附近卫生间和配套设施情况如何？

## 分类

- 一级分类：公共设施
- 二级分类：卫生间

## 标准答案

航站楼：T2航站楼
属性：公众区禁区内
区域：禁区内国际到达
层面：8.4米层
具体位置：80廊桥附近
男卫编号：2-B4-MW2
配套设施：无障碍
开放情况：开放

## 意图标签

- 主意图：restroom_query
- 次意图：未标注

## 风险与来源

- 风险等级：Low
- 来源：Excel 原始资料
- 联系电话：未提供
- 备注：以机场官方最新通知或现场指引为准。
