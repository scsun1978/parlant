---
asset_id: pvg.v2.faee832f98ae38f0d6ffed96
version: v2-7186688f24a1
tenant_id: pvg
title: 的服务时间、乘车地点和收费标准是什么？
section: excel_knowledge
reviewer: v2-legacy-human-review
publisher: v3-staging-migration
published_at: '2026-07-18T20:00:00+08:00'
source_uri: viking://resources/pvg/excel/risk_control/机场交通/机场交通/risk_control-0476-的服务时间-乘车地点和收费标准是什么.md
status: published
knowledge_type: service_information
valid_from: '2026-07-19T00:00:00+08:00'
valid_until: '2026-10-17T00:00:00+08:00'
channel_scope:
- miniprogram
terminal_scope:
- ALL
revoked_at: ''
---
---
title: 的服务时间、乘车地点和收费标准是什么？
source_owner: PVG passenger service
source_type: excel_knowledge
source_id: risk_control-0476
version: 1.0
updated_at: 2026-04-30
effective_from: 2026-04-30
scope: demo_only
confidentiality: internal
review_status: approved_for_demo
---

# 的服务时间、乘车地点和收费标准是什么？

## 分类

- 一级分类：机场交通
- 二级分类：机场交通

## 标准答案

服务时间：0.375
收费标准：青田汽车站 300元

## 意图标签

- 主意图：general_consultation
- 次意图：未标注

## 风险与来源

- 风险等级：Low
- 来源：Excel 原始资料
- 联系电话：未提供
- 备注：以机场官方最新通知或现场指引为准。
