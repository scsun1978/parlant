---
asset_id: pvg.v2.aab8798b47baeda4da4d3d9b
version: v2-26893e5fd434
tenant_id: pvg
title: T1航站楼到达迎客区0米层一楼11号门附近卫生间和配套设施情况如何？
section: excel_knowledge
reviewer: v2-legacy-human-review
publisher: v3-staging-migration
published_at: '2026-07-18T20:00:00+08:00'
source_uri: viking://resources/pvg/excel/risk_control/公共设施/卫生间/risk_control-0219-T1航站楼到达迎客区0米层一楼11号门附近卫生间和配套设施情况如何.md
status: published
knowledge_type: service_information
valid_from: '2026-07-19T00:00:00+08:00'
valid_until: '2026-10-17T00:00:00+08:00'
channel_scope:
- miniprogram
terminal_scope:
- T1
revoked_at: ''
---
---
title: T1航站楼到达迎客区0米层一楼11号门附近卫生间和配套设施情况如何？
source_owner: PVG passenger service
source_type: excel_knowledge
source_id: risk_control-0219
version: 1.0
updated_at: 2026-04-30
effective_from: 2026-04-30
scope: demo_only
confidentiality: internal
review_status: approved_for_demo
---

# T1航站楼到达迎客区0米层一楼11号门附近卫生间和配套设施情况如何？

## 分类

- 一级分类：公共设施
- 二级分类：卫生间

## 标准答案

航站楼：T1航站楼
属性：公众区禁区外
区域：到达迎客区
层面：0米层
具体位置：一楼11号门
男卫编号：T1-7
女卫编号：T1-8
配套设施：家庭卫
开放情况：开放

## 意图标签

- 主意图：restroom_query
- 次意图：未标注

## 风险与来源

- 风险等级：Low
- 来源：Excel 原始资料
- 联系电话：未提供
- 备注：以机场官方最新通知或现场指引为准。
