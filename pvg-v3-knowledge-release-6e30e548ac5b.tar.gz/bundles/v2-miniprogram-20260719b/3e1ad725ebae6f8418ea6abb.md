---
asset_id: pvg.v2.3e1ad725ebae6f8418ea6abb
version: v2-05a7d9c54822
tenant_id: pvg
title: S2卫星厅国内混流区6.9米层H151登机口附近卫生间和配套设施情况如何？
section: excel_knowledge
reviewer: v2-legacy-human-review
publisher: v3-staging-migration
published_at: '2026-07-18T20:00:00+08:00'
source_uri: viking://resources/pvg/excel/risk_control/公共设施/卫生间/risk_control-0441-S2卫星厅国内混流区6-9米层H151登机口附近卫生间和配套设施情况如何.md
status: published
knowledge_type: service_information
valid_from: '2026-07-19T00:00:00+08:00'
valid_until: '2026-10-17T00:00:00+08:00'
channel_scope:
- miniprogram
terminal_scope:
- S2
revoked_at: ''
---
---
title: S2卫星厅国内混流区6.9米层H151登机口附近卫生间和配套设施情况如何？
source_owner: PVG passenger service
source_type: excel_knowledge
source_id: risk_control-0441
version: 1.0
updated_at: 2026-04-30
effective_from: 2026-04-30
scope: demo_only
confidentiality: internal
review_status: approved_for_demo
---

# S2卫星厅国内混流区6.9米层H151登机口附近卫生间和配套设施情况如何？

## 分类

- 一级分类：公共设施
- 二级分类：卫生间

## 标准答案

航站楼：S2卫星厅
属性：公众区禁区内
区域：国内混流区
层面：6.9米层
具体位置：H151登机口
男卫编号：PW-67
配套设施：无障碍
开放情况：开放

## 意图标签

- 主意图：restroom_query
- 次意图：未标注

## 风险与来源

- 风险等级：Low
- 来源：Excel 原始资料
- 联系电话：未提供
- 备注：以机场官方最新通知或现场指引为准。
