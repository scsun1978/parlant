---
asset_id: pvg.v2.e8d5c62fc52a22fd3e6dadbe
version: v2-2e6461616673
tenant_id: pvg
title: 六福菜馆在哪里，营业时间是什么时候？
section: excel_knowledge
reviewer: v2-legacy-human-review
publisher: v3-staging-migration
published_at: '2026-07-18T20:00:00+08:00'
source_uri: viking://resources/pvg/excel/risk_control/商业餐饮/餐饮/risk_control-0735-六福菜馆在哪里-营业时间是什么时候.md
status: published
knowledge_type: service_information
valid_from: '2026-07-19T00:00:00+08:00'
valid_until: '2026-10-17T00:00:00+08:00'
channel_scope:
- miniprogram
terminal_scope:
- ALL
revoked_at: ''
---
---
title: 六福菜馆在哪里，营业时间是什么时候？
source_owner: PVG passenger service
source_type: excel_knowledge
source_id: risk_control-0735
version: 1.0
updated_at: 2026-04-30
effective_from: 2026-04-30
scope: demo_only
confidentiality: internal
review_status: approved_for_demo
---

# 六福菜馆在哪里，营业时间是什么时候？

## 分类

- 一级分类：商业餐饮
- 二级分类：餐饮

## 标准答案

楼域：S2
区域：S2国内出发禁区
商业类型：餐饮
店铺位置：H190登机口附近
营业时间：07：30-21:30
主营范围：餐饮

## 意图标签

- 主意图：restaurant_query
- 次意图：未标注

## 风险与来源

- 风险等级：Low
- 来源：Excel 原始资料
- 联系电话：已在 Demo 知识库中隐藏，需接入官方系统后按权限展示。
- 备注：以机场官方最新通知或现场指引为准。
