---
asset_id: pvg.v2.f80e1cbe8af87fad40b3fa9a
version: v2-4e7c88a3ed0c
tenant_id: pvg
title: S2 2层H171登机口对面附近有什么公用电话服务？
section: excel_knowledge
reviewer: v2-legacy-human-review
publisher: v3-staging-migration
published_at: '2026-07-18T20:00:00+08:00'
source_uri: viking://resources/pvg/excel/risk_control/公共设施/公用电话/risk_control-0094-S2
  2层H171登机口对面附近有什么公用电话服务.md
status: published
knowledge_type: service_information
valid_from: '2026-07-19T00:00:00+08:00'
valid_until: '2026-10-17T00:00:00+08:00'
channel_scope:
- miniprogram
terminal_scope:
- S2
revoked_at: ''
---
---
title: S2 2层H171登机口对面附近有什么公用电话服务？
source_owner: PVG passenger service
source_type: excel_knowledge
source_id: risk_control-0094
version: 1.0
updated_at: 2026-04-30
effective_from: 2026-04-30
scope: demo_only
confidentiality: internal
review_status: approved_for_demo
---

# S2 2层H171登机口对面附近有什么公用电话服务？

## 分类

- 一级分类：公共设施
- 二级分类：公用电话

## 标准答案

服务内容：为旅客提供电话拨打服务
楼域：S2
区域：S2
服务地点：S2 2层H171登机口对面
服务时间：24小时

## 意图标签

- 主意图：general_consultation
- 次意图：未标注

## 风险与来源

- 风险等级：Low
- 来源：Excel 原始资料
- 联系电话：已在 Demo 知识库中隐藏，需接入官方系统后按权限展示。
- 备注：以机场官方最新通知或现场指引为准。
