---
asset_id: pvg.v2.2e3b9dcb6b7e82a3caae022d
version: v2-173e0f26c48f
tenant_id: pvg
title: 国际远机位D227-232登机口附近有什么WIFI取号机服务？
section: excel_knowledge
reviewer: v2-legacy-human-review
publisher: v3-staging-migration
published_at: '2026-07-18T20:00:00+08:00'
source_uri: viking://resources/pvg/excel/risk_control/公共设施/Wi-Fi/risk_control-0056-国际远机位D227-232登机口附近有什么WIFI取号机服务.md
status: published
knowledge_type: service_information
valid_from: '2026-07-19T00:00:00+08:00'
valid_until: '2026-10-17T00:00:00+08:00'
channel_scope:
- miniprogram
terminal_scope:
- ALL
revoked_at: ''
---
---
title: 国际远机位D227-232登机口附近有什么WIFI取号机服务？
source_owner: PVG passenger service
source_type: excel_knowledge
source_id: risk_control-0056
version: 1.0
updated_at: 2026-04-30
effective_from: 2026-04-30
scope: demo_only
confidentiality: internal
review_status: approved_for_demo
---

# 国际远机位D227-232登机口附近有什么WIFI取号机服务？

## 分类

- 一级分类：公共设施
- 二级分类：Wi-Fi

## 标准答案

服务内容：WiFi连接方式：
1.微信小程序连接上网：
第一步：微信登录“上海机场”小程序，选择“浦东机场”，在搜索栏中输入“机场WiFi”并点击进入。
第二步：点击下方“去连接”，自动连接WiFi上网，部分机型上网可能碰到问题，可以使用后续方法上网。
2.手机短信验证上网：
第一步：打开手机的WiFi连接页面，连接机场WiFi，WiFi名称"#AirportPVG-Free-WiFi"。
第二步：打开浏览器会自动弹出认证页面，在输入框中输入手机号并点击“获取验证码”，进行验证。
3.取号机验证上网：
第一步：将证件（二代身份证、港澳通行证、护照）头像面朝下水平放置于取号机扫描区，在取号机上点击屏幕取号。
第二步：打开手机的WiFi连接页面，连接机场WiFi，WiFi名称"#AirportPVG-Free-WiFi"。
第三步：打开浏览器会自动弹出认证页面，输入在取号机上获得的号码，进行验证。
4.移动端证件识别上网：
第一步：打开手机的WiFi连接页面，连接机场WiFi，WiFi名称"#AirportPVG-Free-WiFi"。
第二步：打开浏览器会自动弹出认证页面，选择证件登录。
第三步：根据页面提示进入浏览器拍摄证件照片，进行证件识别认证，识别成功后即可访问互联网。
楼域：T2
区域：国际出发
服务地点：国际远机位D227-232登机口
服务时间：24小时

## 意图标签

- 主意图：wifi_query
- 次意图：未标注

## 风险与来源

- 风险等级：Low
- 来源：Excel 原始资料
- 联系电话：已在 Demo 知识库中隐藏，需接入官方系统后按权限展示。
- 备注：以机场官方最新通知或现场指引为准。
